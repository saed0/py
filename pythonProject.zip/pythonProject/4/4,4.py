def check_age():
    age = int(input("Din ålder: "))

    if age < 25:
        print("Hej ungdom!")
    elif age < 65:
        print("Hej gamling!")
    else:
        print("Hej vuxen!")

check_age()
def check_age():
    age = int(input("Ange din ålder: "))

    if age > 35:
        print("Du är över 35 år gammal.")
    elif age >= 20:
        print("Du är 35 år eller yngre, men får gå på systemet.")
    else:
        print("Du får inte gå på systemet.")

check_age()
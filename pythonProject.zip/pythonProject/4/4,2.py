def check_age():
    age = int(input("Din ålder: "))

    if age < 25:
        print("Du är ung!")
    else:
        print("Du är inte så ung längre!")

    print("Hej då!")
check_age()
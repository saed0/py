def check_age():
    age = int(input("Ange din ålder: "))

    if age >= 30 and age <= 40:
        print("Du är 30+.")
    else:
        print("Du är inte mellan 30 och 40 år gammal.")

check_age()
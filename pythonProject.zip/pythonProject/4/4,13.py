def check_age():
    age = int(input("Ange din ålder: "))

    if age < 18 or age > 65:
        print("Du får billigt pris.")
    else:
        print("Du får inte billigt pris.")

check_age()
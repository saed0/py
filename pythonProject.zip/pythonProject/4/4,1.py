def check_():
    age = int(input("Din ålder: "))
    if age > 30:
        print("Du är gammal!")
    else:
        print("Du är ung!")
        check_()

check_()

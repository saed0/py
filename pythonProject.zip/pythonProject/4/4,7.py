def check_age():
    age = int(input("Ange din ålder: "))

    if age != 35:
        print("Du är inte 35 år gammal.")

check_age()
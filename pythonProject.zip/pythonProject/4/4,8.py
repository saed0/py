def check_age():
    age = int(input("Ange din ålder: "))

    if age > 35:
        print("Du är över 35 år gammal.")
    else:
        print("Du är 35 år eller yngre.")

check_age()
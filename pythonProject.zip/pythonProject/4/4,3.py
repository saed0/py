def check_age():
    age = int(input("Din ålder: "))

    if age < 65:
        print("hej!")
    else:
        print("du är inte så gammal ännu!")

    print("Hej då!")
check_age()
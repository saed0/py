def check_age():
    age = int(input("Ange din ålder: "))

    if age == 20:
        print("Nu får du gå på systemet!")
    else:
        print("Tyvärr, du får inte gå på systemet än.")
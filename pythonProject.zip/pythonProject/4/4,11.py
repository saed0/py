def check_age():
    age = int(input("Ange din ålder: "))

    if age > 12 and age < 19:
        print("Du är tonåring.")
    else:
        print("Du är inte tonåring.")

check_age()
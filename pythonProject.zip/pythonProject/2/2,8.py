import turtle


skolpadda = turtle.Turtle()
skolpadda.speed(1)
skolpadda.color("black")

# Funktion för att rita ett öga
def rita_öga(x, y):
    skolpadda.penup()
    skolpadda.goto(x, y)
    skolpadda.pendown()
    for _ in range(4):
        skolpadda.forward(20)
        skolpadda.left(90)

# Rita huvudet
skolpadda.penup()
skolpadda.goto(-50, -50)
skolpadda.pendown()
for _ in range(4):
    skolpadda.forward(100)
    skolpadda.left(90)

# Rita ögonen
rita_öga(-30, 20)  # Position för vänster öga
rita_öga(10, 20)   # Position för höger öga

# Rita munnen
skolpadda.penup()
skolpadda.goto(-20, -40)
skolpadda.pendown()
skolpadda.forward(40)


skolpadda.hideturtle()


turtle.done()
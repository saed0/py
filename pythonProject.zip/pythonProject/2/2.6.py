import turtle
window = turtle.Screen()
skoldpadda = turtle.Turtle()
skoldpadda.shape("triangle")
skoldpadda.pencolor("red")
side_length = 100
def draw_hexagon(turtle, length):
    for _ in range(6):
        turtle.forward(length)
        turtle.right(60)
draw_hexagon(skoldpadda, side_length)
skoldpadda.hideturtle()
window.exitonclick()

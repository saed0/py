import turtle
skoldpadda = turtle.Turtle()
skoldpadda.speed(1)
skoldpadda.shape("turtle")

# VÅR KOD STARTAR

skoldpadda.forward(100)
skoldpadda.left(90)
skoldpadda.forward(100)
skoldpadda.left(90)
skoldpadda.forward(100)
# VÅR KOD SLUTAR

turtle.exitonclick()


import turtle

# Skapa Turtle-objektet 'skoldpadda'
skoldpadda = turtle.Turtle()
skoldpadda.speed(1)  # Sätter hastigheten till 1, vilket är långsamt

# Funktion för att rita en hexagon
def rita_hexagon():
    for _ in range(6):  # Hexagonen har sex sidor
        skoldpadda.forward(100)  # Ritar en sida av hexagonen
        skoldpadda.left(60)


skoldpadda.penup()
skoldpadda.goto(0, -200)  # Startpositionen är längre ner på skärmen
skoldpadda.pendown()

# Rita tre hexagoner ovanför varandra
for _ in range(3):
    rita_hexagon()
    skoldpadda.penup()
    skoldpadda.left(120)  # Vänd skoldpaddan mot nästa startpunkt
    skoldpadda.forward(100)  # Flytta till nästa startpunkt
    skoldpadda.right(60)  # Rätt vinkeln för att börja rita nästa hexagon
    skoldpadda.pendown()


skoldpadda.hideturtle()


turtle.done()
import turtle

skoldpadda = turtle.Turtle()
skoldpadda.speed(1)
skoldpadda.shape("turtle")

skoldpadda.left(90)
skoldpadda.forward(100)
skoldpadda.left(90)
skoldpadda.forward(100)
skoldpadda.left(90)
skoldpadda.forward(100)
skoldpadda.left(90)
skoldpadda.forward(100)

skoldpadda.penup()
skoldpadda.forward(200)
skoldpadda.pendown()

skoldpadda.left(90)
skoldpadda.forward(100)
skoldpadda.left(90)
skoldpadda.forward(100)
skoldpadda.left(90)
skoldpadda.forward(100)
skoldpadda.left(90)
skoldpadda.forward(100)


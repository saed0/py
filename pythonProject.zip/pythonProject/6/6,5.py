def print_list_with_8():
    numbers = [1, 3, 5, 7, 9]
    numbers.append(8)
    print(numbers)

print_list_with_8()
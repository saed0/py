def print_second_text():
    texts = ["tomat", "banan", "gurka"]
    print(texts[1])

print_second_text()
def print_sorted_list():
    numbers = [1, 9, 5, 3, 7]
    numbers.sort()
    print(numbers)

print_sorted_list()
def print_part_of_list():
    numbers = [1, 3, 5, 7, 9]
    print(numbers[1:])

print_part_of_list()
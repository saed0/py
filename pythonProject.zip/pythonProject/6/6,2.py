def print_specific_numbers():
    numbers = [1,3,5,7,9]
    print("Första talet i listan",numbers[0])
    print("Första talet i listan", numbers[2])

print_specific_numbers()
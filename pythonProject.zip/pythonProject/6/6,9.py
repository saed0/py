def remove_fourth():
    numbers = [1, 3, 5, 7, 9]
    del numbers[3]
    print(numbers)

remove_fourth()
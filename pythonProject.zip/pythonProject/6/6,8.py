def remove_one_3():
    numbers = [1, 3, 3, 3, 3, 5, 7, 9]
    numbers.remove(3)
    print(numbers)

remove_one_3()
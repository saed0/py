def print_specific_number():
    numbers = [1, 3, 5, 7, 9]
    print("Femte talet i listan:", numbers[4])

print_specific_number()
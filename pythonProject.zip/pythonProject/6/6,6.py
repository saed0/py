def add_and_sort():
    numbers = [1, 3, 5, 7, 9]
    numbers.append(4)
    numbers.sort()
    print(numbers)

add_and_sort()
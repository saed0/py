text="Gräsklippare"
print(text[3])

def skriv_ut_dubbla(num):
    dubbel = num * 2
    print("Dubbla av", num, "är:", dubbel)

skriv_ut_dubbla(3)
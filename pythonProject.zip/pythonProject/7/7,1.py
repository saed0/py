def visa_hej():
    print("Välkommen!")

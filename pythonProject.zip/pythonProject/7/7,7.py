def skriv_ut_medelvarde(num1, num2):
    medelvarde = (num1 + num2) / 2
    print("Medelvärdet av", num1, "och", num2, "är:", medelvarde)

skriv_ut_medelvarde(3, 5)
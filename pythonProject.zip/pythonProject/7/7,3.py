def visa_hej():
    print("Välkommen!")

for _ in range(3):
    visa_hej()
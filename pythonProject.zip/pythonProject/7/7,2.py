def visa_hej():
    print("Välkommen!")

visa_hej()
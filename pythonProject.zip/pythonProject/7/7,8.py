def rakna_ut_dubbelt(num):
    dubbelt = num * 2
    return dubbelt

svar = rakna_ut_dubbelt(3)
print(svar)
def skriv_ut_trippla(num):
    trippel = num * 3
    print("Trippel av", num, "är:", trippel)

skriv_ut_trippla(3)
skriv_ut_trippla(7)
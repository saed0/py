def visa_hej():
    print("Välkommen!")

def anvand_visa_hej():
    for _ in range(3):
        visa_hej()

anvand_visa_hej()
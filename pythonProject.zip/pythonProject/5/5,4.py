def print_numbers():
    for i in range(100):
        print(i)


print_numbers()
def print_numbers():
    i = 0
    while i < 100:
        print(i)
        i += 1

print_numbers()



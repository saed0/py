def print_sin_message():
    num_times = int(input("Ange ett heltal: "))

    for _ in range(num_times):
        print("Det är fel att synda.")

print_sin_message()
def print_text():
    num_times = int(input("Ange ett heltal: "))
    text = input("Ange en text: ")

    for _ in range(num_times):
        print(text)

print_text()
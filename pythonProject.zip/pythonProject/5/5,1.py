def print_sin_message():
    for _ in range(100):
        print("Det är fel att synda.")

print_sin_message()
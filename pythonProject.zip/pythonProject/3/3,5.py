favoritfärg= input("Vad är din favritfärg?")
print("Din favortfärg är", favoritfärg)
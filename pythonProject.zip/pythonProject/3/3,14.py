age_str = input("Hur gammal är du? ")


age = int(age_str)


age_in_10_years = age + 10

print("Om 10 år kommer du att vara", age_in_10_years, "år gammal.")
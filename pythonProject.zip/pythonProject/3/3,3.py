print("Välkommen!")
namn= input("Vad heter du?")
print("Hej", namn)

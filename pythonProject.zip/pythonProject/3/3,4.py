höjd=12
bredd= höjd + 5
print("Höjd:", höjd)
print("Bredd:", bredd)
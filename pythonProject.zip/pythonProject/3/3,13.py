namn = input("Vad heter du? ")
ålder  = input("Hur gammal är du? ")
favorit_mat = input("Vad är din favoritmaträtt? ")
print("Hej", namn + "! Du är", ålder, "år gammal och din favoritmaträtt är", favorit_mat + ".")
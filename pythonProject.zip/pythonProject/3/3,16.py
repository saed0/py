alder = input("Hur gammal är du?")
alder = alder + 5
print("Om fem år är du")
print(alder)



i lin 2
ine 2, in <module>
    alder = alder + 5
TypeError: can only concatenate str (not "int") to str

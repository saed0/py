ålder = int(input("Vad är din ålder? "))
print("Din ålder är:", ålder)

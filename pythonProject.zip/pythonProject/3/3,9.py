antal=73
antal=antal + 1
print("Det nya värdet på variabeln antal är:", antal)

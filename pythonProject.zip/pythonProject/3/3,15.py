print("Hello, World!")
print("Master of the Universe!)
print("Ny rad kommer här!")



print("Master of the Universe!) här

ine 2
    print("Master of the Universe!)
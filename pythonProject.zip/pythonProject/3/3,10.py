aldern = int(input("Hur gammal är du? "))
om_fem_år = aldern + 5
print("Om fem år kommer du att vara", om_fem_år, "år gammal.")
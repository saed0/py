age_str = input("Hur gammal är du? ")
age = int(age_str)
half_age = age / 2
print("Om du vore hälften så gammal som du är idag skulle du vara", half_age, "år gammal.")
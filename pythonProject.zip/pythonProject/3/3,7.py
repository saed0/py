a=20
b=a
b=30
print("Värdet på variabeln a är:", a)
print("Värdet på variabeln b är:", b)
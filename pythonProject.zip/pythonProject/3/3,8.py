x = 10
y = x + 5
print("Värdet på variabeln x är:", x)
print("Värdet på variabeln y är:", y)
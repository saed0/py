hastighet =140
print("Hastighet:", hastighet)
